﻿using System;
namespace ISINExtractor
{
    public class Isin
    {
        public string DocumentId;
        public string IsinNumber;
        public string DescriptiveText;
    }
}
