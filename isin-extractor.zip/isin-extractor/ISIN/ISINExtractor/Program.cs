﻿using System;

namespace ISINExtractor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        /*
         * 0. Access txt files from ../Resources and loop through each one to identify ISIN numbers. 
         *    0.a Open a file and parse paragraphs with the |$!$| delimeter. 
         *    0.b Open a file and Identify ISIN numbers with regex pattern: ([A-Z]{2})([A-Z0-9]{9})([0-9]{1}), ref: https://stackoverflow.com/questions/33164718/regex-for-isin-with-at-least-1-number
         *    0.c Store any ISINs and assoc. paragraphs along with document id. 
         * 1. Use open FIGI to capture following fields:
             * name
             * figi
             * ticker
             * marketSector
             * figi url: https://www.openfigi.com/api
         * 2. Identify and parse paragraphs around ISIN |$:$| 
         * 3. Generate a JSON request to send to SearchIndexer.cs method
         * 
         */



    }
}
