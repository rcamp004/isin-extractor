﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
namespace ISINExtractor
{
    public class IsinMatcher
    {
        public IsinMatcher()
        {
            
        }

        public string GetIsinMatch(string inputText)
        {
            

            List < Isin > isin = new List<Isin>();
            //Create a Regex pattern
            string isinPattern = "([A-Z]{2})([A-Z0-9]{9})([0-9]{1})";
            string descriptiveTextPattern = "^(.*?\\|)*$";
            // Create a Regex instance
            Regex rg = new Regex(isinPattern);
            Regex rg1 = new Regex(descriptiveTextPattern);
            //Return all matches
            foreach (Match match in rg.Matches(inputText))
            {
                //instantiate a new ISIN class to store data
                Isin result = new Isin();

                result.DocumentId = "65226806.txt";
                result.IsinNumber = match.Value;

                //Capture text surrounding ISIN
                Match dtMatch = rg1.Match(inputText);
                result.DescriptiveText = dtMatch.Value;

                isin.Add(result);
                Console.WriteLine("'{0}'", match.Value);
                Console.WriteLine("'{0}'", dtMatch.Value);
            }
            //return isin;
            return isin[0].IsinNumber;
        }
    }
}
