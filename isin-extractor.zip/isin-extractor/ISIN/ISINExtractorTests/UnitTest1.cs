using ISINExtractor;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ISINExtractorTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var match = new IsinMatcher();
            string text = "|$!$| EXECUTION VERSION PROHIBITION OF SALES TO EEA AND UK RETAIL INVESTORS – The Notes are not intended to be offered, sold or otherwise made available to and should not be offered, sold or otherwise made available to any retail investor in the European Economic Area(\"EEA\") or the United Kingdom(the \"UK\"). For these purposes, a retail investor means a person who is one(or more) of: (i)a retail client as defined in point(11) of Article 4(1) of Directive 2014 / 65 / EU(as amended \"MiFID II\"); (ii)a customer within the meaning of Directive(EU) 2016 / 97(the \"Insurance Distribution Directive\"), where that customer would not qualify as a professional client as defined in point(10) of Article 4(1) of MiFID II; or(iii) not a qualified investor as defined in Regulation(EU) 2017 / 1129(the \"Prospectus Regulation\").Consequently, no key information document required by Regulation(EU) No 1286 / 2014(the \"PRIIPs Regulation\") for offering or selling the Notes or otherwise making them available to retail investors in the EEA or in the UK has been prepared and therefore offering or selling the Notes or otherwise making them available to any retail investor in the EEA or in the UK may be unlawful under the PRIIPs Regulation.An investment in the Notes does not have the status of a bank deposit and is not within the scope of the deposit protection scheme operated by the Central Bank of Ireland.The Issuer is not and will not be regulated by the Central Bank of Ireland as a result of issuing the Notes.MIFID II PRODUCT GOVERNANCE / PROFESSIONAL INVESTORS AND ECPS ONLY TARGET MARKET - Solely for the purposes of each manufacturer's product approval process, the target market assessment in respect of the Notes has led to the conclusion that: (i) the target market for the Notes is eligible counterparties and professional clients only, each as defined in MiFID II; and (ii) all channels for distribution of the Notes to eligible counterparties and professional clients are appropriate. Any person subsequently offering, selling or recommending the Notes (a \"distributor\") should take into consideration the manufacturers' target market assessment; however, a distributor subject to MiFID II is responsible for undertaking its own target market assessment in respect of the Notes(by either adopting or refining the manufacturers' target market assessment) and determining appropriate distribution channels. Final Terms dated 8 September 2020 GLENCORE CAPITAL FINANCE DAC Legal entity identifier (LEI): 213800HCUCI1HC7X6Q34 Issue of EUR 850,000,000 1.125 per cent. Guaranteed Notes due 2028 Guaranteed by GLENCORE PLC and GLENCORE INTERNATIONAL AG and GLENCORE (SCHWEIZ) AG " +
              "|$!$|" ;
            //Assert.AreEqual("FR0014006BL6", match.GetIsinMatch("This is an ISIN: FR0014006BL6"));
            Assert.AreEqual("CUCI1HC7X6Q3", match.GetIsinMatch(text));

        }
    }
}